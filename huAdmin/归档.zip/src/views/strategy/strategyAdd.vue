<template lang="html">
  <div class="strategyAdd">
    <h1>添加策略</h1>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="scss" scoped>
</style>
